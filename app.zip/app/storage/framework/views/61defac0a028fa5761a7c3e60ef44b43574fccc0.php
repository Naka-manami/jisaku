<?php $__env->startSection('content'); ?>
<main>
  <div class ="container">
    <b>アカウント情報</b>
    <form action="<?php echo e(route('account.conf')); ?>" method="post">
    <?php echo csrf_field(); ?>
    <div class ="label left">
			<label for="account_name">ユーザ名</label>
      <label for="email">メールアドレス</label>
			<label for="name">氏名</label>
			<label for="tel">電話番号</label>
			<label for="post">郵便番号</label>
			<label for="address">住所</label>
    </div>
    <div class ="label right">
			
    </div>
    <!-- ポストで渡す -->
    <button type='submit' class='btn '>次へ</button>
    <button class="delete" class="btn" href="">削除</a>
    </div>
  </form>
  </div>
    
</main>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/resources/views/accounts/account_edit.blade.php ENDPATH**/ ?>