<?php $__env->startSection('content'); ?>
<main>
<h1>商品詳細</h1>
  <div class ="itemdetail">
    <img src="images/pic1.jpeg" id="pic">
    <p><?php echo e($item['item_name']); ?></p>
    <p><?php echo e($item['price']); ?></p>
    <p>♡</p>
  </div>
    <a href="<?php echo e(route('cart',['id'=>$item['id']])); ?>">カートへ</a>
</main>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/resources/views/items/item_detail.blade.php ENDPATH**/ ?>