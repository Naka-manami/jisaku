<?php $__env->startSection('content'); ?>
<div class="container">
<b>カート</b>
<form action="<?php echo e(route('cart',['id'=>$item['id']])); ?>" method="post">
<?php echo csrf_field(); ?>
  <div class="itemcandi">
      <img src="images/pic1.jpeg" id="pic">
    <p><?php echo e($item['item_name']); ?></p>
    <p><?php echo e($item['price']); ?></p>
    <input type="number" name="count" id="count" >
</div>
  <p>合計</p>
  <b>合計額</b>
  <input type="submit" value="次へ">
</form>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/resources/views/cart.blade.php ENDPATH**/ ?>