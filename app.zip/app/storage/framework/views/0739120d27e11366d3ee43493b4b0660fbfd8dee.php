<?php $__env->startSection('content'); ?>
  <div class="container">
  <form action="<?php echo e(route('itembuy.comp',['id'=>$cart['id']])); ?>" method="post">
  <?php echo csrf_field(); ?>
    <h1>注文を確定する</h1>
    <div class="">
       <div class ="total">
        <label for="total">ご請求額</label>
            <?php
              $total = $cart['item']['price'] * $cart['count'];
              ?>
        </div>
            <p><?php echo e($total); ?> 円</p>
      </div>
      <div class ="account">
        <div class ="accountdetail">
          <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <label for="total">お届け先氏名</label>
          <p><?php echo e($user['name']); ?></p>
          <label for="total">お届け先郵便番号</label>
          <p><?php echo e($user['post']); ?></p>
          <label for="total">お届け先住所</label>
          <p><?php echo e($user['address']); ?></p>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
        <a href="<?php echo e(route('user.detail')); ?>">お届け先登録</a>
      </div>
    <input type="submit" value="購入">

  </form>
  
  </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/resources/views/buys/itembuy_conf.blade.php ENDPATH**/ ?>