<?php $__env->startSection('content'); ?>
<main>
    <div class="itemlist">
    <form action="<?php echo e(route('item.registrationcomp')); ?>" method="post">
    <?php echo csrf_field(); ?>
    
          <div class ="itemlist-header">
            <b class ="txet-center">商品登録</b>
          </div>
          <div class="form-group">
            <label for="image"></label>
            <!-- <img src="" id="pic" name="" value="<?php echo e(old('image')); ?>"> -->
            <input type="text" class="form" id="image" name="image" valeu="<?php echo e(old('image')); ?>">

          </div>
          <div class="form-group">
            <label for="item_name">商品名</label>
            <input type="text" class="form" id="item_name" name="item_name" valeu="<?php echo e(old('item_name')); ?>">
          </div>
          <div class="form-group">
            <label for="price">価格</label>
            <input type="text" class="form" id="price" name="price" valeu="<?php echo e(old ('price')); ?>">
          </div>
          <div class="form-group">
            <label for="detail">商品詳細</label>
            <textarea class='form' name='detail' id="detail" name="detail"><?php echo e(old ('detail')); ?></textarea>
          </div>
          <!-- <label for='detail' class='mt-2'>メモ</label>
           <textarea class='form-control' name='detail'><?php echo e(old ('de')); ?></textarea> -->
          <button type='submit' class='btn '>登録</button>
    </form>
    </div>
</main>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/resources/views/items/item_registration.blade.php ENDPATH**/ ?>