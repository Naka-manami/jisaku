<?php $__env->startSection('content'); ?>
<main>
  <div class="container">

  <?php echo csrf_field(); ?>
    <div>
      <p>購入完了しました</p>
    </div>
    <a href="<?php echo e(route('buy')); ?>">ホームへ戻る</a>

  </form>
  
  </div>
</main>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/resources/views/buys/itembuy_comp.blade.php ENDPATH**/ ?>