<?php $__env->startSection('content'); ?>
<div class="container">
<h>お気に入り一覧</h>
<form action="<?php echo e(route('favo.cart')); ?>" method="post">
<?php echo csrf_field(); ?>

  <div class="itemcandi">
    <input type="checkbox" checked="checked" name="checkbox" value="0">
    <a href="遷移させたいURL"> 
      <img src="images/pic1.jpeg" id="pic">
    </a>
    <p class="itemname"></p>
    <p class="price"></p>
    <p class="favodate"></p>
    <button type='submit' class='cartin'>カートに入れる</button>

  </div>
</form>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/resources/views/favo.blade.php ENDPATH**/ ?>