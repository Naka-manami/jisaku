<?php $__env->startSection('content'); ?>
<main>
  <div class ="container">
    <b>アカウント情報</b>
    <div class ="label left">
			<label for="account_name">ユーザ名</label>
      <label for="email">メールアドレス</label>
			<label for="name">氏名</label>
			<label for="tel">電話番号</label>
			<label for="post">郵便番号</label>
			<label for="address">住所</label>
    </div>
    <div class ="label right">
    <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
			<label for="account_name"><?php echo e($user['account_name']); ?></label>
      <label for="email"><?php echo e($user['email']); ?></label>
			<label for="name"><?php echo e($user['name']); ?></label>
			<label for="tel"><?php echo e($user['tel']); ?></label>
			<label for="post"><?php echo e($user['post']); ?></label>
			<label for="address"><?php echo e($user['address']); ?></label>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
   
    <a class="hennkou" href="<?php echo e(route('account.edit')); ?>"><?php echo e(__('変更')); ?></a>
  
  </div>
    
</main>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/resources/views/accounts/account.blade.php ENDPATH**/ ?>