<?php $__env->startSection('content'); ?>
<?php
$totals = 0;
?>
<div class="container">
<h>購入履歴</h>

  <div class="itemcandi">
  <?php $__currentLoopData = $buyhistorys; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $buyhistory): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
   
    <img src="images/pic1.jpeg" id="pic">

    <p><?php echo e($buyhistory['item']['item_name']); ?></p>
    <p>単価</p>
    <p><?php echo e($buyhistory['item']['price']); ?> 円</p>
    <p>数量</p>
    <p><?php echo e($buyhistory['count']); ?> 個</p>
    <p>購入日</p>
    <p><?php echo e($buyhistory['created_at']); ?> </p>
  
  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  </div> 
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/resources/views/buys/buyhistory.blade.php ENDPATH**/ ?>