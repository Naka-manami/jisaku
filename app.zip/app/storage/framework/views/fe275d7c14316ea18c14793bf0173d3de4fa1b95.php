<?php $__env->startSection('content'); ?>
<main >
    <div class="itemlist">
      <div class ="itemlist-header">
        <b class ="txet-center">商品一覧</b>
      </div>
      <div class="itemlist-body">
        <table class="table">
          <thead>
            <tr>
              <th scope='col'>商品名</th>
              <th scope='col'>商品価格</th>
              <th scope='col'>売上個数</th>
              <th scope='col'>売上額</th>
              </th>
            </tr>
          </thead>
          
          <tbody>
          <?php $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
              <th scope ='col'><?php echo e($item['item']['item_name']); ?></th>
              <th scope ='col'><?php echo e($item['item']['price']); ?></th>
              <th scope ='col'><?php echo e($item['count']); ?></th>
              <th scope ='col'>
              <?php
              $total = $item['item']['price'] * $item['count'];
              ?>
              <?php echo e($total); ?>

              </th>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

          </tbody>
        </table>
      </div>
    </div>
</main>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/resources/views/items/admin_itemlist.blade.php ENDPATH**/ ?>