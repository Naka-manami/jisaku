<?php $__env->startSection('content'); ?>
<main>
    <div class="container">
        <div class="row justify-content-center">
            <form action="<?php echo e(route('item.list')); ?>" method="GET"> 
            <div class="price.search">
                <label for="price"><?php echo e(__('価格')); ?></label>

                <div class="kagen">
                <input type="number" name="kagen.price" id="kagen.price" >
                </div>
                〜
                <div class="jougen">
                <input type="number" name="jougen.price" id="jougen.price" >
                </div>

                <div class="searchbox">
                <input type='text' class='form-control' name='keyword'/>
                <input type="submit" value="🔍">
            
            </div>
            </form>
        </div>
    </div>
    <!-- ↓商品一覧 -->
    <div class="container2">
    <!-- 検索結果のアイテムを表示検索していない時は表示なし -->
            <div class="item-list">
                <?php $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="no1">
                    <a href="<?php echo e(route('item.detail',['id'=>$item['id']])); ?>"> 
                        <img src="images/pic1.jpeg" id="pic">
                    </a>
                    <h><?php echo e($item['item_name']); ?></h>
                    <p><?php echo e($item['price']); ?></p>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
    </div>
</main>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/resources/views/home.blade.php ENDPATH**/ ?>