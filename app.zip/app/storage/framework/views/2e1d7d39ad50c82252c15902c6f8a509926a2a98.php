<?php $__env->startSection('content'); ?>
<main>
<div class ="container">
    <b>アカウント情報</b>
    <div class ="container">
    <a class="hennkou" href="<?php echo e(route('admin.home')); ?>"><?php echo e(__('事業者ホームへ戻る')); ?></a>
  
    </div>
    
</main>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/resources/views/items/item_registrationcomp.blade.php ENDPATH**/ ?>