<?php $__env->startSection('content'); ?>
<main>
    <div class='adhomelist'>
        <div class='registration'>
            <a href="<?php echo e(route('item.registration')); ?>"><h1>商品登録</h1></a>
        </div>
        <div class='admin_itemlist'>
            <a href="<?php echo e(route('admin.itemlist')); ?>"><h1>商品リスト</h1></a>
        </div>
        <div class='admin_userlist'>
            <a href="<?php echo e(route('admin.userlist')); ?>"><h1>ユーザリスト</h1></a>
        </div>
    </div>
</main>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/resources/views/admin_home.blade.php ENDPATH**/ ?>