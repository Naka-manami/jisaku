<?php $__env->startSection('content'); ?>
<?php
$totals = 0;
?>
<div class="container">
<b>カート</b>

  <div class="itemcandi">
  <?php $__currentLoopData = $carts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cart): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
  <form action="<?php echo e(route('itembuy.conf',['id'=>$cart['id']])); ?>" method="post">
  <?php echo csrf_field(); ?>
    <img src="images/pic1.jpeg" id="pic">
    <p><?php echo e($cart['item']['item_name']); ?></p>
    <p>単価</p>
    <p><?php echo e($cart['item']['price']); ?> 円</p>
    <p>数量</p>
    <p><?php echo e($cart['count']); ?> 個</p>
    <p>合計</p>
    <?php
    $total = $cart['item']['price'] * $cart['count'];
    $totals += $total;
    ?>
    <p><?php echo e($total); ?> 円</p>

    <input type="submit" value="次へ">
    </form>
  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  </div>
  <b>合計額</b>
  <p><?php echo e($totals); ?> 円</p>

 
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/resources/views/cartlist.blade.php ENDPATH**/ ?>