@extends('layouts.app')

@section('content')
<main>
<div class ="container">
    <b>アカウント情報</b>
    <div class ="container">
    <a class="hennkou" href="{{ route('admin.home') }}">{{__('事業者ホームへ戻る')}}</a>
  
    </div>
    
</main>
@endsection
